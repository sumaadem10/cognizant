public class Guitar implements Playable {
    @Override
    public void play() {
        System.out.println("Guitar is playing: Strum strum!");
    }
}
